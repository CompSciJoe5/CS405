﻿// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <optional>     //  NEW: used for returning success/failure (TODO: overflow/underflow detection)
#include <type_traits>  // NEW: used for checking if type is an integer

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>std::optional containing result or nullopt if overflow detected</returns>
template <typename T>
std::optional<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // TODO: Detect overflow before adding
        if (std::numeric_limits<T>::is_integer &&
            increment > 0 && result > std::numeric_limits<T>::max() - increment)
        {
            return std::nullopt;  // TODO: Return failure if overflow would occur
        }
        result += increment;
    }
    return result;  // TODO: Return correct result if no overflow occurred
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>std::optional containing result or nullopt if underflow detected</returns>
template <typename T>
std::optional<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // TODO: Detect underflow before subtracting
        if (std::numeric_limits<T>::is_integer &&
            decrement > 0 && result < std::numeric_limits<T>::min() + decrement)
        {
            return std::nullopt;  // TODO: Return failure if underflow would occur
        }
        result -= decrement;
    }

    return result;  // TODO: Return correct result if no underflow occurred
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // DO NOT MODIFY (required by instructions)
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    // Without Overflow
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto resultOpt = add_numbers<T>(start, increment, steps);  //  Uses updated function
    if (resultOpt.has_value())  // TODO: Detect if overflow occurred
        std::cout << +resultOpt.value() << std::endl;  //  Show result
    else
        std::cout << "[ERROR: Overflow occurred]" << std::endl;  //  TODO: Show overflow error

    // With Overflow
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    resultOpt = add_numbers<T>(start, increment, steps + 1);  //  Intentionally triggers overflow
    if (resultOpt.has_value())
        std::cout << +resultOpt.value() << std::endl;
    else
        std::cout << "[ERROR: Overflow occurred]" << std::endl;
}

template <typename T>
void test_underflow()
{
    // DO NOT MODIFY (required by instructions)
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    // Without Underflow
    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto resultOpt = subtract_numbers<T>(start, decrement, steps);  //  Uses updated function
    if (resultOpt.has_value())  //  TODO: Detect underflow
        std::cout << +resultOpt.value() << std::endl;
    else
        std::cout << "[ERROR: Underflow occurred]" << std::endl;

    // With Underflow
    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    resultOpt = subtract_numbers<T>(start, decrement, steps + 1);  // Triggers underflow
    if (resultOpt.has_value())
        std::cout << +resultOpt.value() << std::endl;
    else
        std::cout << "[ERROR: Underflow occurred]" << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    const std::string star_line = std::string(50, '*');
    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;
    return 0;
}

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
